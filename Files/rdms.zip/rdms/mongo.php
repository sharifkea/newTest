
<?php
	require __DIR__ . '/vendor/autoload.php';
	require __DIR__ . '/dbName.php';
	$murl=$MongoDb_Connection_String;
	$client = new MongoDB\Client($murl);
		$manager = new MongoDB\Driver\Manager($murl);
	$coll=$Collection_Name;
	$mdb=$Database_Name;
	$colldb=$mdb.".".$coll;
?>
