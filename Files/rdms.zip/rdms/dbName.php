<?php
$MongoDb_Connection_String='mongodb://localhost:27017';
$Database_Name='newdb';
$Collection_Name='testrdms';
?>