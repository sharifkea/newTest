# Bacholor Project - Relational Database Management System (RDMS) for a NoSQL database and providing a library to interact with it using SQL code.

## Purpose
Instructions for interacting with Relational MongoDB Database from PHP project using PHP's MySQLi Extension. 

## Tools
PHP8

## Instructions

1. Copy RDMS folder and pest it to PHP projects working directory. 
2. Open dbName.php and write MongoDB addresses as string and Save. 

Example: MongoDb_Connection_String='mongodb+srv://ronysharif:********@sharifmdb.px3qb.mongodb.net/?retryWrites=true&w=majority';$Database_Name='newdb';$Collection_Name='collone';

3. In the PHP file where you stablishing connection with MySQL (Calling mysqli) include 'require_once '/rdms/convert.php';' and instade of calling mysqli() call mdb_sqli().'

Example: 

<b>Replace:</b>  ($connection = new mysqli("host","user","password","database");) 

<b>With:</b> (require_once '/rdms/convert.php'; $connection = new mdb_mysqli("hostname","username","password","databasename");).

4. "hostname","username","password" and "databasename" should be the same as what you have declared at the of creating the Relational Mongodb on the website.

5. Need to have MongoDB Driver installed on your system to use this Library.

## For the time being:
1. Use only functions quary() and close().
2. When sending 'SELECT----' as paramiter for quary() dont use <b>fetch_assoc()</b>. Treat it as an array.

Example: 

<b>Replace:</b> 
$rows=query('SELECT * FROM TableName');
if ($rows->num_rows > 0) {
while($row = $rows->fetch_assoc()) { }} 

<b>With:</b>
$rows=query('SELECT * FROM TableName');
if ($rows->num_rows > 0) {
foreach($rows as $row){
if(gettype($row)=='array'){ }}}

<style>
h1 {text-align: center;}
</style>
## <h1>>>Enjoy<<</h1>

